Hybrid Roadway Intersection Model Version 1.0
---------------------------------------------

INSTALLATION NOTES

1) Run MSDAC_27.EXE which loads ADO (database) components
2) Restart the system
3) Run setup.exe
4) The HYROAD shortcut will be automatically created at the end of successful installation.