Example 3 Instructions                                              2/9/2010

Example 3 reads in outside data:  

   Alb86.txt is a years worth of meteorological data in PCRAMMET format.
   s1.txt is a year of hourly emissions data for one source in ASCII format.
   
Unzip and load all Example3 files into the same subdirectory 
  as your OBODM executable.

READ THE USER'S GUIDES

The input file is TESTW.INP

The output file should be named anything but **NOT** TESTNEW.OUT

In Windows Explorer, find and double click on OBODM.EXE

Compare your output file with TESTNEW.OUT.  They should be the same.